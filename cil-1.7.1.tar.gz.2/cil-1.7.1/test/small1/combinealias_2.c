
// For linking with combinealias_1.c
int main() {
  foo(42);
  return 0;
}

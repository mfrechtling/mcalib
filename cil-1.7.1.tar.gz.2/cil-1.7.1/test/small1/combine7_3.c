/* struct list2 is not defined */
struct list13 {
  struct list2 *realnext;
  struct list13 *next;
};

enum e1 {
  FIRST = 0,
  SECOND,
} x2;

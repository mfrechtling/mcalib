#include "testharness.h"

int bar;

int main() {
  f1();
  f2();

  SUCCESS;
}

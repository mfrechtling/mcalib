#include <stdio.h>

int f(void) { return 2; }

int main(int argc, char **argv)
{
  f();
  printf("hello world\n");
  return 0;
}
